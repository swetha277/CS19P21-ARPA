def MultiplyTwoNumbers():
	a = 10
	b = 5
	res = a*b
	return str(res)

